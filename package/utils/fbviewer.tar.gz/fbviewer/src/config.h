#define IDSTRING "fbviewer 1.0"
#define DEFAULT_FRAMEBUFFER "/dev/fb0"
#define FBV_SUPPORT_JPEG
#define FBV_SUPPORT_PNG
#define FBV_SUPPORT_BMP
