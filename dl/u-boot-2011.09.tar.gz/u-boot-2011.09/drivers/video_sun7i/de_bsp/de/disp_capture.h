
#ifndef _DISP_SCALER_H_
#define _DISP_SCALER_H_

#include "disp_display_i.h"


#endif
