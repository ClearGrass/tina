
#ifndef _DISP_HWC_H_
#define _DISP_HWC_H_

#include "disp_display_i.h"

/*basic data information definition*/


#endif

