
#include "hdmi_interface.h"


__s32 hdmi_i2c_add_driver(void)
{
	return 0;
}


__s32 hdmi_i2c_del_driver(void)
{
    return 0;
}


