#ifndef  __DEFAULT_PANEL_H__
#define  __DEFAULT_PANEL_H__

#include "panels.h"

extern __lcd_panel_t default_panel;

#endif
