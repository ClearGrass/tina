#ifndef  __OSAL_PARSER_H__
#define  __OSAL_PARSER_H__

#include "OSAL.h"

int OSAL_Script_FetchParser_Data(char *main_name, char *sub_name, int value[], int count);
int OSAL_sw_get_ic_ver(void);

#endif
